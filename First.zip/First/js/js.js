document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth'
    });
    calendar.render();
  });
  const popup = document.querySelector("#no-popup"),
        exit = document.querySelector(".btn-close");


  let fc,currentfc;
  
  
  function a(){
      popup.id = "no-popup"
  }

  function consol(event){
    console.log(event.target)
    popup.id = "popup" 
  }

  function init(){
    exit.addEventListener("click",a)
    for(var i = 0 ; i < fc.length ; i++){
        fc[i].addEventListener("click",consol,true)
        console.log(fc[i])
    }
    
   
  }

  //로드가 다 된 후에 fc제어
  window.addEventListener('DOMContentLoaded', function() { 
    fc = document.querySelectorAll(".fc-daygrid-day");
    currentfc = document.querySelector(".fc-daygrid-day-frame");
    init();
  });
